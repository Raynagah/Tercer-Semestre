package cl.duoc.maullin.aves;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AvesApplicationTests {

	@Test
	void contextLoads() {
	}

}
