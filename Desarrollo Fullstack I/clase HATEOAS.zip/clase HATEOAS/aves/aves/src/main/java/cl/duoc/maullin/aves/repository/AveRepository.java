package cl.duoc.maullin.aves.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import cl.duoc.maullin.aves.model.Ave;

public interface AveRepository extends JpaRepository<Ave,Long> {




}
